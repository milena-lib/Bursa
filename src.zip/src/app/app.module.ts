import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { TabsComponent } from './components/tabs/tabs.component';
// import { TabsPagesComponent } from './shared/tabs-pages/tabs-pages.component';
import { SharedModule } from './shared/shared.module';
import { TabsLinksComponent } from './shared/tabs-links/tabs-links.component';
import { HomeModule } from './pages/home/home.module';

@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,
    TabsComponent,
    
    // TabsLinksComponent
    // TabsPagesComponent
  ],
  // exports: [TabsLinksComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
     SharedModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
