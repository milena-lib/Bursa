import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabs-links',
  templateUrl: './tabs-links.component.html',
  styleUrls: ['./tabs-links.component.css']
})
export class TabsLinksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
