import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabsLinksComponent } from './tabs-links/tabs-links.component';
import { HomeModule } from '../pages/home/home.module';
import { HomeComponent } from '../pages/home/home.component';
import { AboutModule } from '../pages/about/about.module';



@NgModule({
  declarations: [TabsLinksComponent],
  imports: [
    CommonModule,
    // HomeModule
        
  ],
  exports: [//HomeModule,
    TabsLinksComponent
  
  ]
})
export class SharedModule { }
